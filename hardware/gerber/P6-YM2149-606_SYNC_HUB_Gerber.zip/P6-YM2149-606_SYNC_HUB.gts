G04 PAPI-SYNTH 606 Top Soldermask*
M02*
